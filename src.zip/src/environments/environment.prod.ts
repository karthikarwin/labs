export const environment = {
  production: true,
  baseUrl: 'https://www.quantlabs.in/wmp-server/'
  /* baseUrl: 'http://localhost:8080/wmp-server/' */
};

