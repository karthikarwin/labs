import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cas-info',
  templateUrl: './cas-info.component.html',
  styleUrls: ['./cas-info.component.css']
})
export class CasInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
