import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { FundService } from '../../core/_services/fund.service';
import { Scheme } from '../../core/_models/scheme';
import { AuthService } from '../../core/_services/auth.service';
import { User } from '../../core/_models/user';
import { PaymentService } from '../../core/_services/payment.service';
declare var $;
declare var pnCheckoutShared;

@Component({
  selector: 'app-sip-registration',
  templateUrl: './sip-registration.component.html',
  styleUrls: ['./sip-registration.component.css']
})
export class SipRegistrationComponent implements OnInit {
  token: string;
  transId: String;
  response: Boolean;
  responseObj: any;
  sipObj: any;
  user: User;
  folioNumber: any;
  dateFormat: String = 'DD-MM-YYYY';
  mandateAgreed: Boolean;
  agreed: Boolean;
  sipPaymentForm: FormGroup;
  mandateForm: FormGroup;
  isUnits: Boolean;
  step1: Boolean = true;
  step2: Boolean = false;
  step3: Boolean = false;
  fileName: String = '';
  notAnyDate: Boolean = true;
  scheme: Scheme = {
    'code': '',
    'name': '',
    'isActive': '',
    'firstNavDate': 0,
    'planName': 'Direct Plan',
    'invOption': 'Dividend',
    'invType': 'Debt'
  };
  schemes: Array<Scheme>;
  isPhyMandate: Boolean = true;

  failure: Boolean;

  selectedScheme: Scheme;
  amount: any;
  typedAmount: any;
  selectedSchemeCode: String;
  selectedSchemeName: String;
  custBanks: any[];
  sipObjResp: any;
  typingTimer: any;
  typingInterval: any = 2000;

  constructor(
    private fb: FormBuilder,
    private fs: FundService,
    private auth: AuthService,
    private paymentService: PaymentService
  ) {
    this.user = this.auth.getUserFromSession();
  }

  ngOnInit() {
    const that = this;
    this.sipPaymentForm = this.fb.group({
      sipAmount: [0, [Validators.required]],
      sipFrequency: ['', Validators.required],
      sipDate: ['', Validators.required],
      fInsDate: ['', Validators.required],
      lInsDate: ['', Validators.required],
      fInsMonth: [''],
      lInsMonth: [''],
      fInsYear: [''],
      lInsYear: [''],
      untilCancel: [false],
      bank: ['', Validators.required],
      agreed: ['', Validators.required]
    });

    this.fs.getIncompleteTrans(this.user.custId, 'sip-register').subscribe((resp: any) => {
      console.log(resp);
      if (resp === null) {
        this.sipPaymentForm.patchValue({
          sipAmount: 0,
          sipFrequency: '',
          fInsDate: '',
          lInsDate: '',
          bank: 0,
          untilCancel: ''
        });
      } else {
        this.sipObjResp = JSON.parse(resp);
        console.log(this.sipObjResp);
        this.selectedSchemeCode = this.sipObjResp.productId;
        this.selectedSchemeName = this.sipObjResp.productName;
        this.folioNumber = this.sipObjResp.accountNumber;
        this.sipPaymentForm.patchValue({
          sipAmount: this.sipObjResp.amount,
          sipFrequency: this.sipObjResp.frequency,
          fInsDate: this.sipObjResp.firstInstallmentDate,
          lInsDate: this.sipObjResp.lastInstallmentDate,
          bank: this.sipObjResp.bankId,
          untilCancel: this.sipObjResp.continueTillNotify
        });
        this.showStep3();
      }
    }, err => {
      this.sipObjResp = {
        amount: 0,
        accountNumber: '',
        productId: '',
        frequency: '',
        firstInstallmentDate: '',
        lastInstallmentDate: '',
        bankId: 0,
        continueTillNotify: ''
      };
    });
    console.log('form', this.sipPaymentForm);

    /* this.custBanks = */
    if (this.user.clientBankResponse.length > 0) {
      this.custBanks = this.user.clientBankResponse;
    }

    this.mandateForm = this.fb.group({
      mandateType: ['0', Validators.required],
      fileInput: [this.fileName, Validators.required],
      mandateAgreed: ['', Validators.required]
    });

    this.sipPaymentForm.get('agreed').valueChanges
      .subscribe(agreed => {
        if (agreed) {
          this.agreed = true;
        } else {
          this.agreed = false;
        }
      });

    this.mandateForm.get('mandateAgreed').valueChanges
      .subscribe(mandateAgreed => {
        if (mandateAgreed) {
          this.mandateAgreed = true;
        } else {
          this.mandateAgreed = false;
        }
      });

    this.mandateForm.get('mandateType').valueChanges
      .subscribe(isEman => {
        console.log(isEman);
        if (isEman === '1') {
          this.isPhyMandate = false;
        } else {
          this.isPhyMandate = true;
        }
      });
  }


  onFileChange($event) {
    const file = $event.target.files[0];
    this.mandateForm.controls['fileInput'].setValue(file ? file.name : '');
  }

  submitSip() {
    alert('Coming Soon...');
    console.log(this.sipPaymentForm);
  }

  changeFormat(e) {
    console.log(e.target.value);
    if (e.target.value !== '4') {
      this.notAnyDate = false;
    } else {
      this.notAnyDate = true;
    }
    console.log(this.sipPaymentForm.get('fInsDate').value);
  }

  showStep1() {
    this.step1 = true;
    this.step2 = false;
    this.step3 = false;
  }
  showStep2() {
    this.step2 = true;
    this.step1 = false;
    this.step3 = false;
  }
  showStep3() {
    this.step3 = true;
    this.step2 = false;
    this.step1 = false;
  }

  getSchemes(e) {
    const query = e.target.value;
    /* console.log(query.length);
    console.log(e.target.value); */
    const that = this;
    clearTimeout(this.typingTimer);
    if (query.length > 3) {
      this.typingTimer = setTimeout(() => {
        this.fs.getSchemes(query).subscribe( (schemes: Array<Scheme>) => {
          console.log(schemes);
          this.schemes = schemes;
          this.schemes = this.schemes.slice(0, 30);
        });
    }, this.typingInterval);
    }
  }

  selectScheme(code) {
    console.log(code);
    this.selectedSchemeCode = code.code;
    this.selectedSchemeName = code.name;

    this.fs.getSchemeDetails(this.selectedSchemeCode).subscribe((details: Scheme) => {
      /* console.log(details); */
      this.selectedScheme = details;
      console.log(this.selectedScheme);
    });
  }

  setFolio(e) {
    this.folioNumber = e.target.value;
  }

  formatDate(day, month, year): String {
    const fullDate = `${day}-${month}-${year}`;
    return fullDate;
  }
  fetchDay(obj) {
    let day = obj.getDate().toString();
    day = String('00' + day).slice(-2);
    return day;
  }
  fetchMonth(obj) {
    let month = obj.getMonth() + 1;
    month = month.toString();
    month = String('00' + month).slice(-2);
    return month;
  }
  fetchYear(obj) {
    let year = obj.getFullYear();
    year = String('0000' + year).slice(-4);
    return year;
  }

  sendMandate() {
    const custId = this.auth.getUserFromSession().custId;
    const amount = parseInt(this.sipPaymentForm.get('sipAmount').value, 10);
    const frequency = this.sipPaymentForm.get('sipFrequency').value;
    const sipDate = this.sipPaymentForm.get('sipDate').value;
    const untilCancel = this.sipPaymentForm.get('untilCancel').value;
    const fInsDate = this.sipPaymentForm.get('fInsDate').value;
    const lInsDate = this.sipPaymentForm.get('lInsDate').value;
    const bank = parseInt(this.sipPaymentForm.get('bank').value, 10);
    const fInsStrDate = this.formatDate(this.fetchDay(fInsDate), this.fetchMonth(fInsDate), this.fetchYear(fInsDate));
    const lInsStrDate = this.formatDate(this.fetchDay(lInsDate), this.fetchMonth(lInsDate), this.fetchYear(lInsDate));
    /* const fInsStrDate = `${fInsDate.getDate().padStart(2, '0')}-${(fInsDate.getMonth() + 1).padStart(2, '0')}-${fInsDate.getFullYear()}`;
    const lInsStrDate = `${lInsDate.getDate().padStart(2, '0')}-${lInsDate.getMonth() + 1}-${lInsDate.getFullYear()}`; */
    console.log('Date', fInsStrDate);
    console.log('Date', lInsStrDate);
    this.sipObj = {
      customerId: custId,
      productId: this.selectedSchemeCode,
      amount: amount,
      accountNumber: '',
      frequency: frequency,
      firstInstallmentDate: fInsStrDate,
      lastInstallmentDate: lInsStrDate,
      bankId: bank,
      continueTillNotify: untilCancel
    };

    const sipObjStr = {
      customerId: custId,
      productId: this.selectedSchemeCode,
      productName: this.selectedSchemeName,
      amount: amount,
      accountNumber: '',
      frequency: frequency,
      firstInstallmentDate: fInsStrDate,
      lastInstallmentDate: lInsStrDate,
      bankId: bank,
      continueTillNotify: untilCancel
    };

    const updObj = {
      custId: this.user.custId,
      jsonString: JSON.stringify(sipObjStr),
      screenName: 'sip-register'
    };
    this.fs.updateIncompTrans(updObj).subscribe((resp) => {
      console.log(resp);
      this.fs.saveSip(this.sipObj).subscribe((respo) => {
        console.log(respo);
        this.showStep3();
      });
    });
  }


  goToPay() {
    /* this.openPay(); */
    this.typedAmount = this.sipPaymentForm.get('sipAmount').value;
    this.paymentService.getTranxId().subscribe((id: String) => {
      console.log('TranxID -> ', id);
      this.transId = id;
      const strToSend = `T144702|${id}|${this.typedAmount}|1234567890|${this.user.custId}|${this.user.mobile}|${this.user.username}|10-03-2017|01-03-2047|100|M|ADHO|||||9278435371UWATRP`;

      console.log('strToSend -> ', strToSend);

      this.paymentService.getHashed(strToSend).subscribe((str) => {
        console.log('Token -> ', str);
        this.token = str;
        this.openPay();
      }, err => {
        console.log(err);
      });
    }, err => {
      console.log(err.error.text);
    });
  }

  openPay() {
    // alert('ok');
    const configJson = {
      'tarCall': false,
      'features': {
          'showPGResponseMsg': true,
          'enableNewWindowFlow': true
      },
    'consumerData': {
          'deviceId': 'WEBSH2',
          'token': this.token,
            'returnUrl': '',
            'responseHandler': $.proxy(this.handleResponse, this),
            'paymentMode': 'all',
            'merchantLogoUrl': 'https://www.paynimo.com/CompanyDocs/company-logo-md.png',
            'merchantId': 'T144702',
            'consumerId': this.user.custId,
            'consumerMobileNo': this.user.mobile,
            'consumerEmailId': this.user.username,
            'txnId': this.transId,
            'items': [{
                'itemId': 'Test',
                'amount': this.typedAmount,
                'comAmt': '0'
            }],
          'customStyle': {
              'PRIMARY_COLOR_CODE': '#3977b7',
              'SECONDARY_COLOR_CODE': '#FFFFFF',
              'BUTTON_COLOR_CODE_1': '#1969bb',
              'BUTTON_COLOR_CODE_2': '#FFFFFF'
          },
          'accountNo': '1234567890',    // Pass this if accountNo is captured at merchant side for eMandate/eSign
          'accountType': 'Saving',	//  Available options Saving, Current and CC for Cash Credit, only for eSign
          'accountHolderName': 'Name',  // Pass this if accountHolderName is captured at merchant side for eSign only
          'aadharNo': '829801716575',   // Pass this if aadharNo is captured at merchant side for eSign only
          'ifscCode': 'ICIC0000001',        // Pass this if ifscCode is captured at merchant side for eSign only
          'debitStartDate': '10-03-2017',
          'debitEndDate': '01-03-2047',
          'maxAmount': '100',
          'amountType': 'M',
          'frequency': 'ADHO'
      }
    };
    $.pnCheckout(configJson);
    if (configJson.features.enableNewWindowFlow) {
        pnCheckoutShared.openNewWindow();
    }
  }

  handleResponse(res) {
    if (typeof res !== 'undefined' && typeof res.paymentMethod !== 'undefined' && typeof res.paymentMethod.paymentTransaction !== 'undefined' && typeof res.paymentMethod.paymentTransaction.statusCode !== 'undefined' && res.paymentMethod.paymentTransaction.statusCode === '0300') {
        console.log('success');
        this.responseObj = res;
        // success block
    } else if (typeof res !== 'undefined' && typeof res.paymentMethod !== 'undefined' && typeof res.paymentMethod.paymentTransaction !== 'undefined' && typeof res.paymentMethod.paymentTransaction.statusCode !== 'undefined' && res.paymentMethod.paymentTransaction.statusCode === '0398') {
        // initiated block
        console.log(JSON.stringify(res));
    } else {
        // error block
        this.responseObj = JSON.stringify(res);
        console.log('Result : ', this.responseObj);
        this.readResp(res);
    }
    console.log('Result1 : ', this.responseObj);
  }

  readResp(res: any) {
    // alert(res);
    const statusCode = res.paymentMethod.paymentTransaction.statusCode;
    if ( statusCode === '0399' ) {
      this.failure = true;
    } else {
      this.failure = false;
    }
    this.response = true;
    this.responseObj = res;
  }
}
