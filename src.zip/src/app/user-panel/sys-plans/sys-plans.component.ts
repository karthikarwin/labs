import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sys-plans',
  templateUrl: './sys-plans.component.html',
  styleUrls: ['./sys-plans.component.css']
})
export class SysPlansComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
