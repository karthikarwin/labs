import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-example',
  templateUrl: './example.component.html',
  styleUrls: ['./example.component.css']
})
export class ExampleComponent implements OnInit {
  optionss: Array<any> = [
    'one',
    'two',
    'three',
    'four',
    'five',
    'oneone',
    'twotwo',
    'threethree'
  ];

  constructor() { }

  ngOnInit() {
  }

}
