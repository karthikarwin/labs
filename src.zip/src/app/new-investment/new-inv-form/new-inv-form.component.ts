import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FundService } from '../../core/_services/fund.service';
import { Scheme } from '../../core/_models/scheme';
import { AuthService } from '../../core/_services/auth.service';
import { User } from '../../core/_models/user';
import { PaymentService } from '../../core/_services/payment.service';
declare var $;
declare var pnCheckoutShared;

@Component({
  selector: 'app-new-inv-form',
  templateUrl: './new-inv-form.component.html',
  styleUrls: ['./new-inv-form.component.css']
})
export class NewInvFormComponent implements OnInit {
  firstStepActive: Boolean = true;
  secondStepActive: Boolean;
  thirdStepActive: Boolean;
  firstStepCompleted: Boolean;
  secondStepCompleted: Boolean;
  thirdStepCompleted: Boolean;
  transId: String;
  token: String;
  failure: Boolean;
  @ViewChild('para', {read: ElementRef}) paraP: ElementRef;


  lumpsum: any;
  user: User;
  isSipAllowed: Boolean = false;
  error: string;
  response: Boolean;
  responseObj: any;
  step1: Boolean = true;
  step2: Boolean = false;
  step3: Boolean = false;
  selectedScheme: Scheme;
  amount: any;
  typedAmount: any = 10;
  selectedSchemeCode: String;
  selectedSchemeName: String;
  schemes: Array<Scheme> = [];
  typingTimer: any;
  typingInterval: any = 2000;
  otpSuccess: Boolean = false;

  constructor(
    private fs: FundService,
    private auth: AuthService,
    private paymentService: PaymentService
  ) {
    this.user = this.auth.getUserFromSession();
    this.fs.getIncompleteTrans(this.user.custId, 'lumpsum').subscribe((resp: any) => {
      console.log(resp);
      if (resp !== '' || resp !== null) {
        this.lumpsum = JSON.parse(resp);
        console.log(this.lumpsum);
        this.selectedSchemeCode = this.lumpsum.productId;
        this.typedAmount = this.lumpsum.amount;
        this.selectedSchemeName = this.lumpsum.schemeName;
        this.showStep3();
      } else {
        this.lumpsum = {};
      }
    }, err => {
      this.lumpsum = {};
    });
  }

  ngOnInit() {
  }

  showStep1() {
    this.step1 = true;
    this.step2 = false;
    this.step3 = false;
    this.firstStepActive = true;
  }
  showStep2() {
    this.step2 = true;
    this.step1 = false;
    this.step3 = false;
    this.firstStepCompleted = true;
    this.secondStepActive = true;
  }
  showStep3() {
    this.step3 = true;
    this.step2 = false;
    this.step1 = false;
    this.response = false;
    this.firstStepCompleted = true;
    this.secondStepCompleted = true;
    this.thirdStepActive = true;
  }
  showResponse() {
    this.response = true;
    this.thirdStepCompleted = true;
  }

  getSchemes(e) {
    const query = e.target.value;
    /* console.log(query.length);
    console.log(e.target.value); */
    const that = this;
    clearTimeout(this.typingTimer);
    if (query.length > 3) {
      this.typingTimer = setTimeout(() => {
        this.fs.getSchemes(query).subscribe( (schemes: Array<Scheme>) => {
          console.log(schemes);
          this.schemes = schemes;
          this.schemes = this.schemes.slice(0, 30);
        });
    }, this.typingInterval);
    }
  }

  selectScheme(code) {
    console.log(code);
    this.selectedSchemeCode = code.code;
    this.selectedSchemeName = code.name;

    this.fs.getSchemeDetails(this.selectedSchemeCode).subscribe((details: Scheme) => {
      /* console.log(details); */
      this.selectedScheme = details;
      if ((this.selectedScheme.transferInvestDetails.length > 0) && (this.selectedScheme.transferInvestDetails[0].loadType !== 'SIP')) {
        this.isSipAllowed = false;
      } else {
        this.isSipAllowed = true;
      }
      console.log(this.selectedScheme);
    });
  }
  /* saveAmount() {
    console.log(this.typedAmount);
  } */

  saveLumpsum() {
    this.typedAmount = this.amount;
    if (this.amount < 500) {
      this.error = 'Amount should be minimum of 500 INR and should not exceed 100000 INR';
    } else {
      /* const custId = this.auth.getUserFromSession().custId; */
      this.lumpsum = {
        'productId': this.selectedSchemeCode,
        'amount': this.typedAmount,
        'schemeName': this.selectedSchemeName
      };
      console.log('lumpSumObj', this.lumpsum);
      const updObj = {
        custId: this.user.custId,
        screenName: 'lumpsum',
        jsonString: JSON.stringify(this.lumpsum)
      };
      this.fs.updateIncompTrans(updObj).subscribe((resp) => {
        console.log(resp);
        /* this.fs.saveLumpsum(lumsumObj).subscribe((data) => {
            console.log(data);
            this.showStep3();
          }); */
      });
      this.showStep3();
    }
  }

  goToPay() {
    /* this.openPay(); */
    this.paymentService.getTranxId().subscribe((id: String) => {
      console.log('TranxID -> ', id);
      this.transId = id;
      const strToSend = `T144702|${id}|${this.typedAmount}||${this.user.custId}|${this.user.mobile}|${this.user.username}||||||||||9278435371UWATRP`;

      console.log('strToSend -> ', strToSend);

      this.paymentService.getHashed(strToSend).subscribe((str) => {
        console.log('Token -> ', str);
        this.token = str;
        this.openPay();
      }, err => {
        console.log(err);
      });
    }, err => {
      console.log(err.error.text);
    });
  }

  openPay() {
      // alert('ok');
      /* console.log('Here1 ->', this.token);
      console.log('Here2 ->', this.transId); */
      const configJson = {
        'tarCall': false,
        'features': {
            'showPGResponseMsg': true,
            'enableNewWindowFlow': true
        },
      'consumerData': {
            'deviceId': 'WEBSH2',
            'token': this.token,
            'returnUrl': '',
            'responseHandler': $.proxy(this.handleResponse, this),
            'paymentMode': 'all',
            'merchantLogoUrl': 'https://www.paynimo.com/CompanyDocs/company-logo-md.png',
            'merchantId': 'T144702',
            'consumerId': this.user.custId,
            'consumerMobileNo': this.user.mobile,
            'consumerEmailId': this.user.username,
            'txnId': this.transId,
            'items': [{
                'itemId': 'Test',
                'amount': this.typedAmount,
                'comAmt': '0'
            }],
            'customStyle': {
                'PRIMARY_COLOR_CODE': '#3977b7',
                'SECONDARY_COLOR_CODE': '#FFFFFF',
                'BUTTON_COLOR_CODE_1': '#1969bb',
                'BUTTON_COLOR_CODE_2': '#FFFFFF'
            }
        }
      };
      $.pnCheckout(configJson);
      if (configJson.features.enableNewWindowFlow) {
          pnCheckoutShared.openNewWindow();
      }
  }

  handleResponse(res) {
    if (typeof res !== 'undefined' && typeof res.paymentMethod !== 'undefined' && typeof res.paymentMethod.paymentTransaction !== 'undefined' && typeof res.paymentMethod.paymentTransaction.statusCode !== 'undefined' && res.paymentMethod.paymentTransaction.statusCode === '0300') {
        console.log('success');
        this.responseObj = res;
        // success block
    } else if (typeof res !== 'undefined' && typeof res.paymentMethod !== 'undefined' && typeof res.paymentMethod.paymentTransaction !== 'undefined' && typeof res.paymentMethod.paymentTransaction.statusCode !== 'undefined' && res.paymentMethod.paymentTransaction.statusCode === '0398') {
        // initiated block
        console.log(JSON.stringify(res));
    } else {
        // error block
        this.responseObj = JSON.stringify(res);
        console.log('Result : ', this.responseObj);
        this.readResp(res);
    }
    console.log('Result1 : ', this.responseObj);
  }

  readResp(res: any) {
    // alert(res);
    let statusCode = res.paymentMethod.paymentTransaction.statusCode;
    if ( statusCode === '0399' ) {
      this.failure = true;
    } else {
      this.failure = false;
    }
    this.response = true;
    this.responseObj = res;
  }

  otpResponse(boole) {
    console.log(boole);
    this.otpSuccess = JSON.parse(boole);
    if (boole === 'false') {
      alert('Wrong OTP');
    }
  }

}
