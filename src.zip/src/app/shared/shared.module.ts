import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoadingComponent } from './loading/loading.component';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { OtpComponent } from './otp/otp.component';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { RecaptchaModule } from 'ng-recaptcha';
import { RecaptchaFormsModule } from 'ng-recaptcha/forms';
import { LoadingModule } from 'ngx-loading';
import { ModalModule } from 'ngx-bootstrap/modal';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';


@NgModule({
  imports: [
    CommonModule,
    AngularFontAwesomeModule,
    BsDropdownModule.forRoot(),
    BsDatepickerModule.forRoot(),
    TypeaheadModule.forRoot(),
    ModalModule.forRoot(),
    ReactiveFormsModule,
    FormsModule,
    PdfViewerModule,
    RecaptchaModule.forRoot(),
    RecaptchaFormsModule,
    LoadingModule
  ],
  declarations: [LoadingComponent, OtpComponent],
  exports: [
    AngularFontAwesomeModule,
    BsDropdownModule,
    ReactiveFormsModule,
    BsDatepickerModule,
    OtpComponent,
    PdfViewerModule,
    RecaptchaModule,
    RecaptchaFormsModule,
    LoadingModule,
    FormsModule
  ]
})
export class SharedModule { }
