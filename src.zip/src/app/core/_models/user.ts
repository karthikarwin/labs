export interface User {
    custId: Number;
    gmailUser: Boolean;
    mobile: String;
    name: String;
    registrationCompleted: Boolean;
    username: String;
    clientBankResponse: Array<any>;
}
