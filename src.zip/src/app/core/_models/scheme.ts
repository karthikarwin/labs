
const transferInvestDetails =  {
    'effectiveFrom': Number,
    'loadType': String,
    'frequency': String,
    'minInstallments': Number,
    'minInvamount': Number,
    'invdates': String,
    'loadRate': Number
};

export interface Scheme {
        'code': String;
        'name': String;
        'isActive': String;
        'firstNavDate': Number;
        'minRedemptionAmt'?: null;
        'minRedemptionUnit'?: null;
        'minBalanceAmt'?: null;
        'minBalanceUnit'?: null;
        'planName': 'Direct Plan';
        'invOption': 'Dividend';
        'invType': 'Debt';
        'expenseRatio'?: null;
        'expenseRatioDate'?: null;
        'avgAum'?: null;
        'registrarId'?: 9;
        'avgAumQuarterly'?: null;
        'ytm'?: null;
        'maxInvestamt'?: 0;
        'addtnlMinInvestAmt'?: 0;
        'addtnlMulInvesAamt'?: 0;
        'dividendReinvest'?: false;
        'switchinAvail'?: null;
        'switchoutAvail'?: false;
        'minLockinPeriod'?: '1172 Days';
        'month_3'?: 1;
        'month_6'?: 1;
        'year_1'?: null;
        'year_3'?: null;
        'year_5'?: null;
        'inception'?: 5;
        's_1year'?: null;
        's_3year'?: null;
        's_5year'?: null;
        's_sinceinception'?: null;
        'navDate'?: Number;
        'nav'?: Number;
        'adjustedNav'?: Number;
        'loadDetails'?: [
            {
                'effectiveFrom'?: Number,
                'loadType'?: String,
                'fromDays'?: Number,
                'toDays'?: Number,
                'loadRate'?: null
            },
            {
                'effectiveFrom'?: Number,
                'loadType'?: String,
                'fromDays'?: 0,
                'toDays'?: 0,
                'loadRate'?: null
            }
        ];
        'transferInvestDetails'?: Array<any>;
        'rpDetails'?: [
            {
                'riskProfileName'?: String,
                'instrumentDescription'?: String
            },
            {
                'riskProfileName'?: String,
                'instrumentDescription'?: String
            }
        ];
}

